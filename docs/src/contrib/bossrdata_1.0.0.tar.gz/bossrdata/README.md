# bossrdata

This is a companion dataset for the `bossr` package. To learn more, please visit the [`bossr` pkgdown site](https://pennsive.github.io/bossr/).
